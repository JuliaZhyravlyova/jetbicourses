sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(DateFormat) {
	"use strict";

	return {

		formatHighlight: function(sCreatedBy) {
			if (sCreatedBy === "D1B1000037") {
				return "Success";
			}

			return "None";
		},

		formatEditDeleleVisible: function(sCreatedBy) {
			return sCreatedBy === "D1B1000037";
		},

			creationInfo: function(oDate, sFullName) {
			if (!oDate || !sFullName) {
				return "";
				
			}
			
			var oDateFormat = DateFormat.getDateTimeInstance({
				pattern: "EEE, MMM dd, yyyy"
			});
			sFullName = sFullName.split(" ")[1];
			var sDate = oDateFormat.format(oDate);
			var dToday = new Date().getTime();
			var dDateTime = oDate.getTime();

			var iMssDiff = dToday - dDateTime;
			
			var iDays =  parseInt(iMssDiff / (1000 * 60 * 60 * 24));
			var sDays = !!iDays ? iDays + " " + this.getResourceBundle().getText("Days") : "";

			var iHours =  parseInt((iMssDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

			var sHours = !!iHours ? iHours + " " + this.getResourceBundle().getText("Hours") : "";

			var iMinutes = parseInt((iMssDiff % (1000 * 60 * 60)) / (1000 * 60));

			var sMinutes = !!iMinutes ? iMinutes + " " + this.getResourceBundle().getText("Minutes") : "";
			
			var sDateAgo = sDays + " " + sHours + " " + sMinutes;
			if (!sDateAgo.trim()) {
				sDateAgo = this.getResourceBundle().getText("LessThenMinute");
			}
			return this.getResourceBundle().getText("tableModifiedByColumnTitle", [sFullName, sDate, sDateAgo]);
		},

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		}

	};

});