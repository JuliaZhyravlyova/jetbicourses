sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(DateFormat) {
	"use strict";

	return {

		formatHighlight: function(sCreatedBy) {
			if (sCreatedBy === "D1B1000037") {
				return "Success";
			}

			return "None";
		},

		formatEditDeleleVisible: function(sCreatedBy) {
			return sCreatedBy === "D1B1000037";
		},

		creationInfo: function(oDate, sFullName) {
			if (!oDate || !sFullName) {
				return "";
				
			}
			
			var oDateFormat = DateFormat.getDateTimeInstance({
				pattern: "EEE, MMM dd, yyyy"
			});
			sFullName = sFullName.split(" ")[1];
			var sDate = oDateFormat.format(oDate);
			var dToday = new Date();
			var dDateTime = oDate;

			var c = dToday - dDateTime;
			var iDays = Math.abs(dToday.getUTCDate() -  dDateTime.getUTCDate());
			var sDays = !!iDays ? iDays + " " + this.getResourceBundle().getText("Days") : "";

			var iHours =  Math.abs(dToday.getUTCHours() -  dDateTime.getUTCHours());

			var sHours = !!iHours ? iHours + " " + this.getResourceBundle().getText("Hours") : "";

			var iMinutes = Math.abs(dToday.getUTCMinutes() -  dDateTime.getUTCMinutes());

			var sMinutes = !!iMinutes ? iMinutes + " " + this.getResourceBundle().getText("Minutes") : "";
			
			var sDateAgo = sDays + " " + sHours + " " + sMinutes;
			if (!sDateAgo.trim()) {
				sDateAgo = this.getResourceBundle().getText("LessThenMinute");
			}
			return this.getResourceBundle().getText("tableModifiedByColumnTitle", [sFullName, sDate, sDateAgo]);
		},

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		}

	};

});